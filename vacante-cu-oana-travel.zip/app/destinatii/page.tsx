import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

const destinations = [
  {
    id: 1,
    name: "Grecia",
    description: "Plaje superbe, istorie bogată și gastronomie delicioasă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 350€",
    slug: "grecia",
    locations: ["Santorini", "Mykonos", "Creta", "Rodos", "Corfu"],
  },
  {
    id: 2,
    name: "Turcia",
    description: "Resorts all-inclusive, peisaje spectaculoase și cultură vibrantă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 299€",
    slug: "turcia",
    locations: ["Antalya", "Bodrum", "Istanbul", "Marmaris", "Alanya"],
  },
  {
    id: 3,
    name: "Spania",
    description: "Soare, plaje și arhitectură impresionantă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 399€",
    slug: "spania",
    locations: ["Barcelona", "Madrid", "Mallorca", "Tenerife", "Ibiza"],
  },
  {
    id: 4,
    name: "Italia",
    description: "Artă, istorie și bucătărie renumită în toată lumea",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 450€",
    slug: "italia",
    locations: ["Roma", "Veneția", "Florența", "Milano", "Sicilia"],
  },
  {
    id: 5,
    name: "Franța",
    description: "Romantism, cultură și gastronomie de excepție",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 480€",
    slug: "franta",
    locations: ["Paris", "Nisa", "Marsilia", "Lyon", "Bordeaux"],
  },
  {
    id: 6,
    name: "Portugalia",
    description: "Peisaje pitorești, plaje și vinuri excelente",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 420€",
    slug: "portugalia",
    locations: ["Lisabona", "Porto", "Algarve", "Madeira", "Azore"],
  },
  {
    id: 7,
    name: "Croația",
    description: "Coaste spectaculoase, ape cristaline și orașe medievale",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 380€",
    slug: "croatia",
    locations: ["Dubrovnik", "Split", "Zagreb", "Hvar", "Plitvice"],
  },
  {
    id: 8,
    name: "Egipt",
    description: "Istorie fascinantă, piramide și stațiuni all-inclusive",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 499€",
    slug: "egipt",
    locations: ["Cairo", "Hurghada", "Sharm El Sheikh", "Luxor", "Alexandria"],
  },
]

export default function DestinationsPage() {
  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Destinații</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Explorează cele mai populare destinații pentru vacanța ta perfectă
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Caută destinații..." className="pl-9" />
        </div>
        <Button>Caută</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {destinations.map((destination) => (
          <Link key={destination.id} href={`/destinatii/${destination.slug}`}>
            <Card className="overflow-hidden h-full transition-transform hover:scale-[1.02]">
              <div className="relative h-48">
                <Image
                  src={destination.image || "/placeholder.svg"}
                  alt={destination.name}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-4">
                <div>
                  <h3 className="font-bold text-lg">{destination.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{destination.description}</p>
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium">Locații populare:</h4>
                  <p className="text-xs text-muted-foreground mt-1">{destination.locations.join(", ")}</p>
                </div>
                <p className="mt-4 font-semibold text-primary">{destination.price}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
