import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const offers = [
  {
    id: 1,
    title: "Santorini - Vacanță de vis",
    description: "7 nopți de cazare la hotel 4*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "899€",
    newPrice: "699€",
    discount: "-22%",
    slug: "santorini-vacanta-de-vis",
    period: "15 Iun - 22 Iun 2023",
    features: ["Zbor direct", "Transfer aeroport", "Ghid turistic"],
  },
  {
    id: 2,
    title: "Antalya All Inclusive",
    description: "7 nopți de cazare la resort 5*, all inclusive, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "799€",
    newPrice: "599€",
    discount: "-25%",
    slug: "antalya-all-inclusive",
    period: "10 Iun - 17 Iun 2023",
    features: ["All inclusive", "Aqua park", "Plajă privată"],
  },
  {
    id: 3,
    title: "Barcelona City Break",
    description: "4 nopți de cazare la hotel 3*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "599€",
    newPrice: "499€",
    discount: "-17%",
    slug: "barcelona-city-break",
    period: "20 Iun - 24 Iun 2023",
    features: ["Tur ghidat", "Bilete muzee", "Transfer aeroport"],
  },
  {
    id: 4,
    title: "Creta - Vacanță la mare",
    description: "7 nopți de cazare la hotel 4*, demipensiune, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "849€",
    newPrice: "699€",
    discount: "-18%",
    slug: "creta-vacanta-la-mare",
    period: "25 Iun - 2 Iul 2023",
    features: ["Demipensiune", "Piscină", "Plajă aproape"],
  },
  {
    id: 5,
    title: "Istanbul - Oraș între două continente",
    description: "5 nopți de cazare la hotel 4*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "649€",
    newPrice: "549€",
    discount: "-15%",
    slug: "istanbul-oras-intre-doua-continente",
    period: "5 Iul - 10 Iul 2023",
    features: ["Tur ghidat", "Croazieră Bosfor", "Transfer aeroport"],
  },
  {
    id: 6,
    title: "Roma - Orașul etern",
    description: "5 nopți de cazare la hotel 3*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "699€",
    newPrice: "599€",
    discount: "-14%",
    slug: "roma-orasul-etern",
    period: "12 Iul - 17 Iul 2023",
    features: ["Tur ghidat", "Bilete Colosseum", "Transfer aeroport"],
  },
]

export default function SpecialOffersPage() {
  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Oferte Speciale</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Profită de cele mai bune oferte pentru vacanța ta de vis
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {offers.map((offer) => (
          <Card key={offer.id} className="overflow-hidden h-full">
            <div className="relative h-48">
              <Badge className="absolute top-2 right-2 z-10 bg-primary">{offer.discount}</Badge>
              <Image src={offer.image || "/placeholder.svg"} alt={offer.title} fill className="object-cover" />
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg">{offer.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{offer.description}</p>
              <p className="text-sm mt-2">Perioada: {offer.period}</p>
              <div className="mt-2">
                <h4 className="text-sm font-medium">Include:</h4>
                <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                  {offer.features.map((feature, index) => (
                    <li key={index}>• {feature}</li>
                  ))}
                </ul>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-sm line-through text-muted-foreground">{offer.oldPrice}</span>
                <span className="font-bold text-lg text-primary">{offer.newPrice}</span>
                <span className="text-xs text-muted-foreground">/ persoană</span>
              </div>
              <Link href={`/oferte-speciale/${offer.slug}`} className="mt-4 block">
                <Button className="w-full">Vezi oferta</Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
