import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Contactează-ne</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Suntem aici pentru a te ajuta să planifici vacanța perfectă. Contactează-ne și îți vom răspunde cât mai curând
          posibil.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-bold mb-6">Trimite-ne un mesaj</h2>
          <form className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="first-name" className="text-sm font-medium">
                  Prenume
                </label>
                <Input id="first-name" name="first-name" required />
              </div>
              <div className="space-y-2">
                <label htmlFor="last-name" className="text-sm font-medium">
                  Nume
                </label>
                <Input id="last-name" name="last-name" required />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-medium">
                Email
              </label>
              <Input id="email" name="email" type="email" required />
            </div>
            <div className="space-y-2">
              <label htmlFor="phone" className="text-sm font-medium">
                Telefon
              </label>
              <Input id="phone" name="phone" type="tel" />
            </div>
            <div className="space-y-2">
              <label htmlFor="message" className="text-sm font-medium">
                Mesaj
              </label>
              <Textarea id="message" name="message" rows={5} required />
            </div>
            <Button type="submit" className="w-full">
              Trimite mesaj
            </Button>
          </form>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Informații de contact</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <MapPin className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Adresă</h3>
                <p className="text-muted-foreground mt-1">Str. Exemplu nr. 123, București, România</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Phone className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Telefon</h3>
                <p className="text-muted-foreground mt-1">
                  <a href="tel:+40123456789" className="hover:text-primary">
                    +40 123 456 789
                  </a>
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Mail className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Email</h3>
                <p className="text-muted-foreground mt-1">
                  <a href="mailto:contact@oanatravel.ro" className="hover:text-primary">
                    contact@oanatravel.ro
                  </a>
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Clock className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Program</h3>
                <div className="text-muted-foreground mt-1">
                  <p>Luni - Vineri: 09:00 - 18:00</p>
                  <p>Sâmbătă: 10:00 - 14:00</p>
                  <p>Duminică: Închis</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 h-64 rounded-lg overflow-hidden border">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d91158.11409353752!2d26.0311541!3d44.4377401!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40b1f93abf3cad4f%3A0xac0632e37c9ca628!2sBucure%C8%99ti!5e0!3m2!1sro!2sro!4v1649252970562!5m2!1sro!2sro"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  )
}
