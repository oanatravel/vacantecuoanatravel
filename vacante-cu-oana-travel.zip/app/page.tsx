import Hero from "@/components/hero"
import FeaturedDestinations from "@/components/featured-destinations"
import SpecialOffers from "@/components/special-offers"
import Testimonials from "@/components/testimonials"
import Newsletter from "@/components/newsletter"
import AboutSection from "@/components/about-section"

export default function Home() {
  return (
    <div className="flex flex-col gap-16 py-8">
      <Hero />
      <FeaturedDestinations />
      <SpecialOffers />
      <AboutSection />
      <Testimonials />
      <Newsletter />
    </div>
  )
}
