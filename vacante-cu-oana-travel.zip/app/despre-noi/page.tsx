import Image from "next/image"
import { Check } from "lucide-react"

export default function AboutPage() {
  const team = [
    {
      name: "Oana Popescu",
      role: "Fondator & Director",
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      name: "Mihai Ionescu",
      role: "Manager Vânzări",
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      name: "Elena Dumitrescu",
      role: "Consultant Turism",
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      name: "Andrei Popa",
      role: "Consultant Turism",
      image: "/placeholder.svg?height=400&width=400",
    },
  ]

  const values = [
    {
      title: "Pasiune pentru călătorii",
      description: "Suntem pasionați de călătorii și ne place să împărtășim această pasiune cu clienții noștri.",
    },
    {
      title: "Atenție la detalii",
      description: "Ne asigurăm că fiecare detaliu al vacanței tale este perfect planificat.",
    },
    {
      title: "Experiență personalizată",
      description: "Oferim experiențe personalizate în funcție de preferințele și bugetul fiecărui client.",
    },
    {
      title: "Suport 24/7",
      description: "Suntem disponibili oricând pentru a oferi asistență în timpul călătoriei tale.",
    },
  ]

  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Despre Noi</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Descoperă povestea Oana Travel și echipa noastră dedicată
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image src="/placeholder.svg?height=800&width=600" alt="Despre Oana Travel" fill className="object-cover" />
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Povestea noastră</h2>
          <p className="text-muted-foreground mb-4">
            Oana Travel a fost fondată în 2010 din pasiunea pentru călătorii și dorința de a oferi experiențe de neuitat
            clienților noștri. De-a lungul anilor, am crescut constant, devenind una dintre cele mai de încredere
            agenții de turism din România.
          </p>
          <p className="text-muted-foreground mb-4">
            Misiunea noastră este să transformăm visele de călătorie în realitate, oferind servicii de înaltă calitate
            la prețuri competitive. Ne mândrim cu atenția la detalii și cu relațiile strânse pe care le-am dezvoltat cu
            partenerii noștri din întreaga lume.
          </p>
          <p className="text-muted-foreground">
            Cu o echipă de profesioniști pasionați și dedicați, suntem mereu pregătiți să oferim cele mai bune sfaturi
            și să creăm itinerarii personalizate pentru fiecare client în parte.
          </p>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold text-center mb-8">Valorile noastre</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => (
            <div key={index} className="bg-muted p-6 rounded-lg">
              <div className="flex items-center gap-2 mb-4">
                <Check className="h-5 w-5 text-primary" />
                <h3 className="font-bold">{value.title}</h3>
              </div>
              <p className="text-sm text-muted-foreground">{value.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-center mb-8">Echipa noastră</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <div key={index} className="text-center">
              <div className="relative h-64 w-64 mx-auto rounded-full overflow-hidden mb-4">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="font-bold text-lg">{member.name}</h3>
              <p className="text-sm text-muted-foreground">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
