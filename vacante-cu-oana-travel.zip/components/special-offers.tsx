import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const offers = [
  {
    id: 1,
    title: "Santorini - Vacanță de vis",
    description: "7 nopți de cazare la hotel 4*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "899€",
    newPrice: "699€",
    discount: "-22%",
    slug: "santorini-vacanta-de-vis",
  },
  {
    id: 2,
    title: "Antalya All Inclusive",
    description: "7 nopți de cazare la resort 5*, all inclusive, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "799€",
    newPrice: "599€",
    discount: "-25%",
    slug: "antalya-all-inclusive",
  },
  {
    id: 3,
    title: "Barcelona City Break",
    description: "4 nopți de cazare la hotel 3*, mic dejun inclus, zbor direct",
    image: "/placeholder.svg?height=600&width=800",
    oldPrice: "599€",
    newPrice: "499€",
    discount: "-17%",
    slug: "barcelona-city-break",
  },
]

export default function SpecialOffers() {
  return (
    <section className="container py-8 bg-muted/50 rounded-lg">
      <div className="flex flex-col items-center text-center mb-12">
        <h2 className="text-3xl font-bold tracking-tight">Oferte Speciale</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Profită de cele mai bune oferte pentru vacanța ta de vis
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {offers.map((offer) => (
          <Card key={offer.id} className="overflow-hidden h-full">
            <div className="relative h-48">
              <Badge className="absolute top-2 right-2 z-10 bg-primary">{offer.discount}</Badge>
              <Image src={offer.image || "/placeholder.svg"} alt={offer.title} fill className="object-cover" />
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold text-lg">{offer.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{offer.description}</p>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-sm line-through text-muted-foreground">{offer.oldPrice}</span>
                <span className="font-bold text-lg text-primary">{offer.newPrice}</span>
                <span className="text-xs text-muted-foreground">/ persoană</span>
              </div>
              <Link href={`/oferte-speciale/${offer.slug}`} className="mt-4 block">
                <Button className="w-full">Vezi oferta</Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="flex justify-center mt-10">
        <Link href="/oferte-speciale">
          <Button variant="outline" className="text-base">
            Vezi toate ofertele
          </Button>
        </Link>
      </div>
    </section>
  )
}
