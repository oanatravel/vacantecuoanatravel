"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

export default function Newsletter() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setEmail("")
      toast({
        title: "Succes!",
        description: "Te-ai abonat cu succes la newsletter-ul nostru.",
      })
    }, 1000)
  }

  return (
    <section className="container py-12 bg-primary text-primary-foreground rounded-lg">
      <div className="flex flex-col items-center text-center">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Abonează-te la newsletter</h2>
        <p className="mt-4 text-lg max-w-2xl">Primește cele mai bune oferte și noutăți direct în inbox-ul tău</p>
        <form onSubmit={handleSubmit} className="mt-6 flex w-full max-w-md gap-2">
          <Input
            type="email"
            placeholder="Adresa ta de email"
            className="bg-primary-foreground text-primary-foreground placeholder:text-muted-foreground"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" variant="secondary" disabled={isLoading}>
            {isLoading ? "Se trimite..." : "Abonează-te"}
          </Button>
        </form>
        <p className="mt-3 text-sm">Nu facem spam. Poți să te dezabonezi oricând.</p>
      </div>
      <Toaster />
    </section>
  )
}
