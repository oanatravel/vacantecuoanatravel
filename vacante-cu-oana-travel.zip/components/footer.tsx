import Link from "next/link"
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Oana Travel</h3>
            <p className="text-muted-foreground">
              Agenție de turism cu experiență, dedicată să ofere clienților cele mai bune experiențe de călătorie.
            </p>
            <div className="flex gap-4 mt-4">
              <Link href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                <Instagram className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
              </Link>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Destinații populare</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/destinatii/grecia" className="text-muted-foreground hover:text-primary">
                  Grecia
                </Link>
              </li>
              <li>
                <Link href="/destinatii/turcia" className="text-muted-foreground hover:text-primary">
                  Turcia
                </Link>
              </li>
              <li>
                <Link href="/destinatii/spania" className="text-muted-foreground hover:text-primary">
                  Spania
                </Link>
              </li>
              <li>
                <Link href="/destinatii/italia" className="text-muted-foreground hover:text-primary">
                  Italia
                </Link>
              </li>
              <li>
                <Link href="/destinatii/franta" className="text-muted-foreground hover:text-primary">
                  Franța
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Link-uri utile</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/despre-noi" className="text-muted-foreground hover:text-primary">
                  Despre noi
                </Link>
              </li>
              <li>
                <Link href="/termeni-si-conditii" className="text-muted-foreground hover:text-primary">
                  Termeni și condiții
                </Link>
              </li>
              <li>
                <Link href="/politica-de-confidentialitate" className="text-muted-foreground hover:text-primary">
                  Politica de confidențialitate
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary">
                  Întrebări frecvente
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-muted-foreground">Str. Exemplu nr. 123, București, România</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <Link href="tel:+40123456789" className="text-muted-foreground hover:text-primary">
                  +40 123 456 789
                </Link>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <Link href="mailto:contact@oanatravel.ro" className="text-muted-foreground hover:text-primary">
                  contact@oanatravel.ro
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Oana Travel. Toate drepturile rezervate.</p>
        </div>
      </div>
    </footer>
  )
}
