import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Hero() {
  return (
    <div className="relative h-[600px] w-full overflow-hidden">
      <Image
        src="/placeholder.svg?height=1080&width=1920"
        alt="Destinație de vacanță"
        width={1920}
        height={1080}
        className="absolute inset-0 object-cover w-full h-full"
        priority
      />
      <div className="absolute inset-0 hero-gradient"></div>
      <div className="container relative z-10 flex flex-col items-center justify-center h-full text-center">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
          Descoperă lumea cu Oana Travel
        </h1>
        <p className="mt-6 max-w-lg text-xl text-white">
          Călătorii memorabile, experiențe autentice și destinații de vis la prețuri accesibile.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-4">
          <Link href="/destinatii">
            <Button size="lg" className="text-base">
              Explorează destinații
            </Button>
          </Link>
          <Link href="/contact">
            <Button
              size="lg"
              variant="outline"
              className="text-base bg-white/10 text-white hover:bg-white/20 hover:text-white"
            >
              Contactează-ne
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
