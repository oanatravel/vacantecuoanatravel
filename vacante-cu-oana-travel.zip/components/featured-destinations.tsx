import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

const destinations = [
  {
    id: 1,
    name: "Grecia",
    description: "Plaje superbe, istorie bogată și gastronomie delicioasă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 350€",
    slug: "grecia",
  },
  {
    id: 2,
    name: "Turcia",
    description: "Resorts all-inclusive, peisaje spectaculoase și cultură vibrantă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 299€",
    slug: "turcia",
  },
  {
    id: 3,
    name: "Spania",
    description: "Soare, plaje și arhitectură impresionantă",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 399€",
    slug: "spania",
  },
  {
    id: 4,
    name: "Italia",
    description: "Artă, istorie și bucătărie renumită în toată lumea",
    image: "/placeholder.svg?height=600&width=800",
    price: "de la 450€",
    slug: "italia",
  },
]

export default function FeaturedDestinations() {
  return (
    <section className="container py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h2 className="text-3xl font-bold tracking-tight">Destinații populare</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Descoperă cele mai căutate destinații pentru vacanța ta perfectă
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {destinations.map((destination) => (
          <Link key={destination.id} href={`/destinatii/${destination.slug}`}>
            <Card className="overflow-hidden h-full transition-transform hover:scale-[1.02]">
              <div className="relative h-48">
                <Image
                  src={destination.image || "/placeholder.svg"}
                  alt={destination.name}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg">{destination.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{destination.description}</p>
                  </div>
                </div>
                <p className="mt-4 font-semibold text-primary">{destination.price}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
      <div className="flex justify-center mt-10">
        <Link href="/destinatii">
          <Button variant="outline" className="text-base">
            Vezi toate destinațiile
          </Button>
        </Link>
      </div>
    </section>
  )
}

import { Button } from "@/components/ui/button"
