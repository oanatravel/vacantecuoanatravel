import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Maria Popescu",
    location: "București",
    text: "Am avut o experiență minunată în Grecia datorită Oana Travel. Totul a fost organizat perfect, de la zbor până la cazare și excursii. Cu siguranță voi apela din nou la serviciile lor!",
    rating: 5,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 2,
    name: "Ion Ionescu",
    location: "Cluj-Napoca",
    text: "Vacanța în Turcia a fost exact ce aveam nevoie. Oana Travel ne-a oferit un pachet complet la un preț excelent. Recomand cu încredere!",
    rating: 5,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 3,
    name: "Elena Dumitrescu",
    location: "Timișoara",
    text: "Am călătorit cu familia în Spania și totul a fost perfect. Oana Travel a fost mereu disponibilă pentru orice întrebare și ne-a oferit sfaturi utile. Mulțumim!",
    rating: 4,
    image: "/placeholder.svg?height=100&width=100",
  },
]

export default function Testimonials() {
  return (
    <section className="container py-8">
      <div className="flex flex-col items-center text-center mb-12">
        <h2 className="text-3xl font-bold tracking-tight">Ce spun clienții noștri</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-3xl">
          Descoperă experiențele clienților care au călătorit cu Oana Travel
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.id} className="h-full">
            <CardContent className="p-6">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="text-muted-foreground mb-6">"{testimonial.text}"</p>
              <div className="flex items-center gap-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden">
                  <Image
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <p className="font-medium">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
