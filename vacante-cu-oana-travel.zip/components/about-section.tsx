import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export default function AboutSection() {
  const benefits = [
    "Experiență de peste 10 ani în turism",
    "Consultanți dedicați și pasionați de călătorii",
    "Prețuri competitive și transparente",
    "Asistență 24/7 în timpul călătoriei",
    "Parteneriate cu cele mai bune hoteluri și companii aeriene",
  ]

  return (
    <section className="container py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image src="/placeholder.svg?height=800&width=600" alt="Despre Oana Travel" fill className="object-cover" />
        </div>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Despre Oana Travel</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Oana Travel este o agenție de turism cu experiență, dedicată să ofere clienților săi cele mai bune
            experiențe de călătorie. Ne pasă de fiecare detaliu al vacanței tale și ne asigurăm că totul este perfect
            organizat.
          </p>
          <ul className="mt-6 space-y-3">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
          <div className="mt-8">
            <Link href="/despre-noi">
              <Button>Află mai multe despre noi</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
